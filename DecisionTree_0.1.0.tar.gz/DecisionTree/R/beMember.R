#' Be Member


beMember <- function(a, b) {
  for (i in b) {
    if (identical(i, a)) {return(T)}
  }
  return(F)
}
