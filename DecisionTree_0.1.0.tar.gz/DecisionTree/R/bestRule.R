#' Best Rule


bestRule <- function(myData, classes, featureSpace) {
  errors <- rep(x = -1, times = ncol(myData))
  values <- rep(x = NA, times = ncol(myData))
  for (thfeat in 1:ncol(myData)) {
    if (length(table(myData[,thfeat]))!=1) {
      subsplit <- find_node(features = myData[,thfeat], class = classes)
      errors[thfeat] <- subsplit[[2]]
      values[thfeat] <- subsplit[[1]]
    }
  }
  thisrule <- newRule(feature = colnames(myData)[which.min(errors)], judgement = "(<)=", value = values[which.min(errors)])
  inde <- 2
  return(thisrule)
}
